
import pdf from 'pdf-parse';
import mammoth from 'mammoth';

export async function parseFile(file: File): Promise<string> {
    const buffer = Buffer.from(await file.arrayBuffer());
    const type = file.type;

    if (type === 'application/pdf') {
        const data = await pdf(buffer);
        return data.text;
    }

    if (type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
        const result = await mammoth.extractRawText({ buffer });
        return result.value;
    }

    throw new Error(`Unsupported file type: ${type}`);
}
